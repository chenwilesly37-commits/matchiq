# MatchIQ — All-Market Football Analysis

MatchIQ is an independent Next.js football-analysis application. It includes a responsive match centre, fixture search, date and league filters, market category filters, expandable per-fixture estimates, a prediction API, and a performance page.

## Markets in the interface

- Match result: home/draw/away, double-independent outcome foundation
- Goals: over/under, home and away team goals, both teams to score, correct-score candidates
- Corners: total and team totals
- Discipline: yellow-card totals and red-card occurrence
- Fouls and offsides
- Total shots and shots on target, including home/away shots on target
- First-half score candidates, second-half score candidates, full-time score candidates, and goals by half

## Important model/data status

The project defaults to **demo mode**. Demo fixtures are fictional examples. Goal probabilities use a basic independent Poisson baseline. Corners, cards, fouls, offsides, and shot markets currently use generic priors, not verified fixture-specific historical forecasts. First/second-half goal allocation uses a simple 44%/56% prior. These values must not be presented as validated or guaranteed predictions.

The API-Football adapter loads real fixtures when configured. Real fixture data alone does not make all-market probabilities accurate: the next production step is ingesting licensed historical team/player/referee statistics, persisting predictions and results, calibrating models, and backtesting each market by competition.

## Requirements

- Node.js 20 or newer
- npm
- An API-Football account/key for real fixtures (optional for local demo)
- GitHub and Vercel accounts to deploy publicly

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Connect API-Football

Set these variables in `.env.local` (never use a `NEXT_PUBLIC_` prefix for the secret key):

```env
FOOTBALL_DATA_PROVIDER=api-football
FOOTBALL_DATA_API_KEY=your_private_api_key
FOOTBALL_DATA_BASE_URL=https://v3.football.api-sports.io
```

Restart the dev server. The server-side fixture adapter sends the API key in the `x-apisports-key` header and requests fixtures by date. Confirm the competitions and statistics included in your subscription before relying on coverage. API-Football documentation: https://www.api-football.com/documentation-v3

To return to demo mode, set `FOOTBALL_DATA_PROVIDER=demo`.

## API routes

- `GET /api/fixtures?date=YYYY-MM-DD`
- `GET /api/predictions?date=YYYY-MM-DD`

The predictions endpoint returns fixtures, baseline goal probabilities, market groups, model version, data source, and a disclaimer.

## Deploy to Vercel

1. Create a GitHub repository and push this project.
2. Sign in at https://vercel.com/ and import the repository.
3. Add `FOOTBALL_DATA_PROVIDER`, `FOOTBALL_DATA_API_KEY`, and `FOOTBALL_DATA_BASE_URL` under the Vercel project's Environment Variables. Keep the API key server-only.
4. Deploy. Vercel will issue a public `*.vercel.app` URL.
5. Test `/api/fixtures?date=YYYY-MM-DD` and `/api/predictions?date=YYYY-MM-DD` on the deployed domain.

I cannot publish to a GitHub/Vercel account without the owner completing those authenticated steps. Do not send passwords or private tokens in chat.

## Production checklist

- Ingest recent fixtures and stats for each selected league/season.
- Verify provider coverage for corners, fouls, offsides, cards and shots by competition.
- Add team and opponent-specific distributions; add referee/player features where available.
- Persist predictions before kickoff and final outcomes in Supabase.
- Backtest per market/league and calibrate probabilities before displaying a confidence label.
- Add rate limiting, caching, error monitoring, data-source attribution, privacy and terms pages.

MatchIQ is independent and not affiliated with any bookmaker or league. Verify your data-provider licence for commercial display and redistribution of data and logos.
