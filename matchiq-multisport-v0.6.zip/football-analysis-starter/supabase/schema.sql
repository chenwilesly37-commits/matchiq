-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.leagues (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_league_id text not null,
  name text not null,
  country text,
  season integer,
  created_at timestamptz not null default now(),
  unique(provider, provider_league_id, season)
);

create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_team_id text not null,
  name text not null,
  country text,
  created_at timestamptz not null default now(),
  unique(provider, provider_team_id)
);

create table if not exists public.fixtures (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_fixture_id text not null,
  league_id uuid references public.leagues(id),
  home_team_id uuid references public.teams(id),
  away_team_id uuid references public.teams(id),
  kickoff timestamptz not null,
  status text not null check (status in ('scheduled','live','finished','postponed','cancelled')),
  home_goals integer,
  away_goals integer,
  raw_source_updated_at timestamptz,
  created_at timestamptz not null default now(),
  unique(provider, provider_fixture_id)
);

create table if not exists public.team_match_stats (
  id uuid primary key default gen_random_uuid(),
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  team_id uuid not null references public.teams(id),
  is_home boolean not null,
  goals_for integer,
  goals_against integer,
  shots integer,
  shots_on_target integer,
  possession numeric,
  source text not null,
  captured_at timestamptz not null default now(),
  unique(fixture_id, team_id)
);

create table if not exists public.predictions (
  id uuid primary key default gen_random_uuid(),
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  model_version text not null,
  home_expected_goals numeric not null,
  away_expected_goals numeric not null,
  over_15_probability numeric not null check (over_15_probability between 0 and 1),
  over_25_probability numeric not null check (over_25_probability between 0 and 1),
  over_35_probability numeric not null check (over_35_probability between 0 and 1),
  under_25_probability numeric not null check (under_25_probability between 0 and 1),
  under_35_probability numeric not null check (under_35_probability between 0 and 1),
  generated_at timestamptz not null default now(),
  unique(fixture_id, model_version, generated_at)
);

create table if not exists public.prediction_results (
  id uuid primary key default gen_random_uuid(),
  prediction_id uuid not null unique references public.predictions(id) on delete cascade,
  total_goals integer not null,
  over_15_hit boolean not null,
  over_25_hit boolean not null,
  over_35_hit boolean not null,
  brier_score_over_25 numeric,
  evaluated_at timestamptz not null default now()
);

create table if not exists public.odds_snapshots (
  id uuid primary key default gen_random_uuid(),
  fixture_id uuid not null references public.fixtures(id) on delete cascade,
  provider text not null,
  market text not null,
  selection text not null,
  decimal_odds numeric not null check (decimal_odds > 1),
  captured_at timestamptz not null default now()
);

-- Enable RLS before exposing any table through a client-facing Supabase key.
alter table public.leagues enable row level security;
alter table public.teams enable row level security;
alter table public.fixtures enable row level security;
alter table public.team_match_stats enable row level security;
alter table public.predictions enable row level security;
alter table public.prediction_results enable row level security;
alter table public.odds_snapshots enable row level security;

-- No public policies are created intentionally. Add narrowly scoped SELECT policies
-- only for tables/data you intend to expose. Keep writes on trusted server routes.
