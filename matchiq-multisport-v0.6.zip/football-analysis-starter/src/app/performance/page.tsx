import Link from "next/link";
import { ArrowLeft, BarChart3, Database, Gauge } from "lucide-react";

export default function PerformancePage() {
  return (
    <main className="min-h-screen px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-mint"><ArrowLeft size={16} /> Back to fixtures</Link>
        <div className="mt-6 rounded-3xl border border-white/10 bg-panel p-6 sm:p-8">
          <div className="flex items-center gap-3 text-mint"><BarChart3 size={22} /><span className="text-sm font-semibold">MODEL MONITORING</span></div>
          <h1 className="mt-3 text-3xl font-black">Prediction performance</h1>
          <p className="mt-3 max-w-2xl leading-6 text-slate-300">Track predictions saved before kick-off against final results. This starter does not claim historical accuracy because no real predictions have been evaluated yet.</p>
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <Metric icon={<Database size={18} />} label="Evaluated predictions" value="—" note="Awaiting stored results" />
            <Metric icon={<Gauge size={18} />} label="Brier score" value="—" note="Lower is better; needs outcomes" />
            <Metric icon={<BarChart3 size={18} />} label="Calibration" value="—" note="Compare estimated vs actual rates" />
          </div>
          <div className="mt-7 rounded-2xl border border-white/10 bg-black/10 p-5">
            <h2 className="font-bold">How performance will be measured</h2>
            <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-6 text-slate-300">
              <li>Save each prediction and model version before the match starts.</li>
              <li>After full-time, record the final score and whether each goal market was successful.</li>
              <li>Calculate Brier score for probability quality and report hit rate with the sample size.</li>
              <li>Separate results by league, market and probability band; never hide losing predictions.</li>
            </ul>
          </div>
          <p className="mt-5 text-xs leading-5 text-slate-500">Next implementation step: schedule a server-side job to persist predictions into Supabase before kick-off and evaluate finished fixtures using the schema in <code>supabase/schema.sql</code>.</p>
        </div>
      </div>
    </main>
  );
}
function Metric({ icon, label, value, note }: { icon: React.ReactNode; label: string; value: string; note: string }) {
  return <div className="rounded-2xl bg-white/[0.04] p-4"><div className="flex items-center gap-2 text-mint">{icon}<span className="text-xs text-slate-300">{label}</span></div><p className="mt-3 text-2xl font-black">{value}</p><p className="mt-1 text-xs text-slate-500">{note}</p></div>;
}
