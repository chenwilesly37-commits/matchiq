import { NextRequest, NextResponse } from "next/server";
import { getFixtures } from "@/lib/football/provider";
import { predictGoals } from "@/lib/predictions/poisson";
import { predictAllMarkets } from "@/lib/predictions/markets";

export const dynamic = "force-dynamic";
export async function GET(request: NextRequest) {
  try {
    const date = request.nextUrl.searchParams.get("date") || undefined;
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return NextResponse.json({ error: "date must use YYYY-MM-DD" }, { status: 400 });
    }
    const fixtures = await getFixtures(date);
    const predictions = fixtures.map((fixture) => ({
      ...fixture,
      probabilities: predictGoals(fixture.homeExpectedGoals, fixture.awayExpectedGoals),
      markets: predictAllMarkets(fixture),
      modelVersion: "matchiq-poisson-prior-0.2",
      generatedAt: new Date().toISOString(),
    }));
    return NextResponse.json({
      predictions,
      source: process.env.FOOTBALL_DATA_PROVIDER === "api-football" && process.env.FOOTBALL_DATA_API_KEY ? "api-football" : "demo",
      modelVersion: "matchiq-poisson-prior-0.2",
      disclaimer: "Probabilities are estimates, not guarantees. Non-goal markets use generic priors until licensed historical data is integrated.",
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("predictions route error", error);
    return NextResponse.json({ error: "Unable to load predictions. Check provider settings, API credentials, and API quota." }, { status: 502 });
  }
}
