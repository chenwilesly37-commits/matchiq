import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MatchIQ — All-Market Football Analysis",
  description: "Independent football analysis for goals, corners, cards, fouls, offsides, shots on target and half-time scorelines.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
