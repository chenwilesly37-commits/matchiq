import type { Fixture } from "@/lib/football/types";
import { predictGoals } from "@/lib/predictions/poisson";

function pct(value: number) { return `${Math.round(value * 100)}%`; }
function localTime(value: string) {
  return new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Africa/Douala" }).format(new Date(value));
}

export function FixtureCard({ fixture }: { fixture: Fixture }) {
  const goals = predictGoals(fixture.homeExpectedGoals, fixture.awayExpectedGoals);
  return (
    <article className="rounded-2xl border border-white/10 bg-panel p-4 shadow-lg shadow-black/10">
      <div className="mb-3 flex items-center justify-between gap-3 text-xs text-slate-400">
        <span>{fixture.country ? `${fixture.country} · ` : ""}{fixture.league}</span>
        <span className={fixture.status === "live" ? "font-semibold text-rose-300" : ""}>
          {fixture.status === "live" ? "LIVE" : fixture.status === "finished" ? "FT" : localTime(fixture.kickoff)}
        </span>
      </div>
      <div className="grid grid-cols-[1fr_auto] items-center gap-3">
        <div className="space-y-3">
          <p className="font-semibold text-white">{fixture.homeTeam}</p>
          <p className="font-semibold text-white">{fixture.awayTeam}</p>
        </div>
        <div className="text-right text-lg font-bold tabular-nums">
          <p>{fixture.homeGoals ?? "–"}</p>
          <p>{fixture.awayGoals ?? "–"}</p>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2 border-t border-white/10 pt-3">
        <Metric label="Over 1.5" value={pct(goals.over15)} />
        <Metric label="Over 2.5" value={pct(goals.over25)} highlight />
        <Metric label="Under 3.5" value={pct(goals.under35)} />
      </div>
      <p className="mt-3 text-xs text-slate-500">Expected total goals: {goals.expectedTotalGoals.toFixed(2)} · baseline model</p>
    </article>
  );
}
function Metric({ label, value, highlight = false }: { label: string; value: string; highlight?: boolean }) {
  return <div className={`rounded-xl p-2 ${highlight ? "bg-emerald-300/10" : "bg-white/[0.03]"}`}>
    <p className="text-[11px] text-slate-400">{label}</p>
    <p className={`mt-1 font-semibold ${highlight ? "text-mint" : "text-slate-100"}`}>{value}</p>
  </div>;
}
